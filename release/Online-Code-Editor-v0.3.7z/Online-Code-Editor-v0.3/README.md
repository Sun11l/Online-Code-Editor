﻿# ONLINE CODE EDITOR

---

### 项目描述
使用Node.js，实现一个简单的在线代码编辑工具，并在树莓派上部署服务
### 项目进展
#### 18-09-30
- [x] 在github上创建项目
- [x] 实现基础的HTML页面模板
- [x] 允许保存文本到本地
#### 18-10-01
- [x] 使用AJAX优化
- [x] 允许打开本地文件

### Demo
**Version 0.3**
![Demo](demo/demo_1001.gif)